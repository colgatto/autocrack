#!/bin/sh
aireplay-ng -a $2 -c $3 -0 $4 $1
